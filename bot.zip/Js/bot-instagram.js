// Js/bot-instagram.js
const { IgApiClient } = require('instagram-private-api');
const fs = require('fs');
const path = require('path');

const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

const DB_FILE = path.join(__dirname, '..', 'data', 'followed.json');

function loadFollowedDB() {
  if (!fs.existsSync(DB_FILE)) return { followed: [] };
  try {
    return JSON.parse(fs.readFileSync(DB_FILE, 'utf8'));
  } catch {
    return { followed: [] };
  }
}

function saveFollowedDB(db) {
  fs.writeFileSync(DB_FILE, JSON.stringify(db, null, 2));
}

/* ---------- LOGIN ---------- */
async function createClient({ username, password, cookie }) {
  const ig = new IgApiClient();
  ig.state.generateDevice(username);

  if (cookie) {
    try {
      await ig.state.deserialize(cookie);
      console.log('🔑 Pakai cookie:', username);
      return ig;
    } catch (err) {
      console.log('⚠️ Cookie invalid, fallback password:', err.message);
    }
  }

  await ig.simulate.preLoginFlow();
  const user = await ig.account.login(username, password);

  process.nextTick(async () => {
    try {
      await ig.simulate.postLoginFlow();
    } catch (_) {}
  });

  console.log('✅ Login:', user.username);
  return ig;
}

async function exportCookie(ig) {
  const state = await ig.state.serialize();
  delete state.constants;
  delete state.cookies;
  return JSON.stringify(state);
}

/* ---------- AUTO FOLLOW ---------- */
async function autoFollow(ig, {
  target,
  source = 'target_followers',
  limit = 10,
  delayMin = 45000,
  delayMax = 90000,
  whitelist = [],
  onLog = console.log,
}) {
  const me = await ig.account.currentUser();
  const meId = me.pk;

  onLog(`🚀 Auto follow | target=${target} limit=${limit}`);

  let candidates = [];

  if (source === 'target_followers' || source === 'target_following') {
    const targetId = await ig.user.getIdByUsername(target);
    const feed =
      source === 'target_followers'
        ? ig.feed.accountFollowers(targetId)
        : ig.feed.accountFollowing(targetId);

    while (candidates.length < limit * 3 && feed.isMoreAvailable()) {
      const page = await feed.items();
      candidates.push(...page);
    }
  } else if (source === 'hashtag') {
    const feed = ig.feed.tags(target.replace('#', ''));
    const seen = new Set();
    while (candidates.length < limit * 3 && feed.isMoreAvailable()) {
      const posts = await feed.items();
      for (const p of posts) {
        const u = p.user?.username;
        if (u && !seen.has(u)) {
          seen.add(u);
          candidates.push(p.user);
        }
      }
    }
  }

  const db = loadFollowedDB();
  const wl = whitelist.map((x) => x.toLowerCase());
  let done = 0;

  for (const user of candidates) {
    if (done >= limit) break;
    const uname = user.username;

    if (!uname) continue;
    if (user.pk === meId) continue;
    if (user.is_private) continue;
    if (wl.includes(uname.toLowerCase())) continue;
    if (db.followed.some((f) => f.username === uname)) continue;

    try {
      await ig.friendship.create(user.pk);
      onLog(`   ➕ Follow: ${uname}`);

      db.followed.push({ username: uname, pk: user.pk, followed_at: Date.now() });
      saveFollowedDB(db);
      done++;

      if (done < limit) {
        const wait = Math.floor(Math.random() * (delayMax - delayMin + 1)) + delayMin;
        onLog(`   ⏳ Tunggu ${Math.round(wait / 1000)}s...`);
        await sleep(wait);
      }
    } catch (err) {
      onLog(`   ❌ Gagal follow ${uname}: ${err.message}`);
      if (err.response?.body?.message === 'feedback_required') {
        onLog('   🛑 Kena rate-limit, stop.');
        break;
      }
    }
  }

  onLog(`✅ Selesai. Total follow: ${done}`);
  return { followed: done };
}

/* ---------- AUTO LIKE ---------- */
async function autoLike(ig, {
  target,
  limit = 10,
  delayMin = 30000,
  delayMax = 60000,
  onLog = console.log,
}) {
  onLog(`🚀 Auto like | target=${target} limit=${limit}`);

  const userId = await ig.user.getIdByUsername(target);
  const feed = ig.feed.user(userId);
  const posts = await feed.items();

  let done = 0;
  const targetPosts = posts.slice(0, limit);

  for (const post of targetPosts) {
    if (done >= limit) break;

    try {
      await ig.media.like({
        mediaId: post.id,
        moduleInfo: { module_name: 'profile' },
      });

      const link = 'https://www.instagram.com/p/' + post.code + '/';
      onLog(`   ❤️ Like: ${link}`);
      done++;

      if (done < targetPosts.length) {
        const wait = Math.floor(Math.random() * (delayMax - delayMin + 1)) + delayMin;
        onLog(`   ⏳ Tunggu ${Math.round(wait / 1000)}s...`);
        await sleep(wait);
      }
    } catch (err) {
      onLog(`   ❌ Gagal like ${post.code}: ${err.message}`);
      if (err.response?.body?.message === 'feedback_required') {
        onLog('   🛑 Kena rate-limit, stop.');
        break;
      }
    }
  }

  onLog(`✅ Selesai. Total like: ${done}`);
  return { liked: done };
}

module.exports = {
  createClient,
  exportCookie,
  autoFollow,
  autoLike,
};