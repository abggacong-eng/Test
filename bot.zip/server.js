// server.js
require('dotenv').config();

const express = require('express');
const cors = require('cors');
const fs = require('fs');
const path = require('path');
const {
  createClient,
  exportCookie,
  autoFollow,
  autoLike,
} = require('./Js/bot-instagram');

const app = express();
const PORT = process.env.PORT || 3000;
const API_KEY = process.env.API_KEY || 'rahasia123';

app.use(cors());
app.use(express.json({ limit: '1mb' }));
app.use(express.static(__dirname));

const DATA_DIR = path.join(__dirname, 'data');
const BOTS_FILE = path.join(DATA_DIR, 'bots.json');

function ensureData() {
  if (!fs.existsSync(DATA_DIR)) fs.mkdirSync(DATA_DIR);
  if (!fs.existsSync(BOTS_FILE)) {
    fs.writeFileSync(BOTS_FILE, JSON.stringify({ bots: [] }, null, 2));
  }
}

function loadBots() {
  ensureData();
  try {
    return JSON.parse(fs.readFileSync(BOTS_FILE, 'utf8'));
  } catch {
    return { bots: [] };
  }
}

function saveBots(db) {
  fs.writeFileSync(BOTS_FILE, JSON.stringify(db, null, 2));
}

function publicBot(bot) {
  return {
    id: bot.id,
    username: bot.username,
    has_password: !!bot.password,
    has_cookie: !!bot.cookie,
    status: bot.status || 'idle',
    created_at: bot.created_at,
    last_run: bot.last_run || null,
    last_result: bot.last_result || null,
  };
}

function auth(req, res, next) {
  const key = req.headers['x-api-key'] || req.query.api_key;
  if (key !== API_KEY) {
    return res.status(401).json({ ok: false, error: 'Unauthorized' });
  }
  next();
}

const logs = {};
function logTo(botId, msg) {
  if (!logs[botId]) logs[botId] = [];
  const line = `[${new Date().toLocaleTimeString()}] ${msg}`;
  console.log(`(${botId})`, msg);
  logs[botId].push(line);
  if (logs[botId].length > 300) logs[botId].shift();
}

/* ---------- ROUTES ---------- */
app.get('/api/health', (req, res) => {
  res.json({ ok: true, time: Date.now() });
});

app.post('/api/auth', (req, res) => {
  const { api_key } = req.body;
  if (api_key !== API_KEY) {
    return res.status(401).json({ ok: false, error: 'API key salah' });
  }
  res.json({ ok: true });
});

app.get('/api/bots', auth, (req, res) => {
  const db = loadBots();
  res.json({ ok: true, bots: db.bots.map(publicBot) });
});

app.post('/api/bots', auth, (req, res) => {
  const { username, password, cookie } = req.body;
  if (!username || (!password && !cookie)) {
    return res.status(400).json({ ok: false, error: 'username & (password/cookie) wajib' });
  }

  const db = loadBots();
  if (db.bots.some((b) => b.username === username)) {
    return res.status(409).json({ ok: false, error: 'Username sudah ada' });
  }

  const bot = {
    id: 'b' + Date.now().toString(36) + Math.random().toString(36).slice(2, 6),
    username,
    password: password || '',
    cookie: cookie || '',
    status: 'idle',
    created_at: Date.now(),
  };
  db.bots.push(bot);
  saveBots(db);

  res.json({ ok: true, bot: publicBot(bot) });
});

app.put('/api/bots/:id', auth, (req, res) => {
  const { password, cookie } = req.body;
  const db = loadBots();
  const bot = db.bots.find((b) => b.id === req.params.id);
  if (!bot) return res.status(404).json({ ok: false, error: 'Bot tidak ditemukan' });

  if (typeof password === 'string') bot.password = password;
  if (typeof cookie === 'string') bot.cookie = cookie;
  saveBots(db);

  res.json({ ok: true, bot: publicBot(bot) });
});

app.delete('/api/bots/:id', auth, (req, res) => {
  const db = loadBots();
  const idx = db.bots.findIndex((b) => b.id === req.params.id);
  if (idx === -1) return res.status(404).json({ ok: false, error: 'Bot tidak ditemukan' });

  db.bots.splice(idx, 1);
  saveBots(db);
  res.json({ ok: true });
});

/* ---------- LOGIN BOT ---------- */
app.post('/api/bots/:id/login', auth, async (req, res) => {
  const db = loadBots();
  const bot = db.bots.find((b) => b.id === req.params.id);
  if (!bot) return res.status(404).json({ ok: false, error: 'Bot tidak ditemukan' });

  logTo(bot.id, '🔄 Test login...');
  try {
    const ig = await createClient({
      username: bot.username,
      password: bot.password,
      cookie: bot.cookie,
    });

    const cookie = await exportCookie(ig);
    bot.cookie = cookie;
    bot.password = '';
    bot.status = 'logged_in';
    saveBots(db);

    logTo(bot.id, '✅ Login berhasil, cookie tersimpan.');
    res.json({ ok: true, bot: publicBot(bot) });
  } catch (err) {
    bot.status = 'error';
    saveBots(db);
    logTo(bot.id, `❌ Login gagal: ${err.message}`);
    res.status(500).json({ ok: false, error: err.message });
  }
});

/* ---------- AUTO FOLLOW ---------- */
app.post('/api/bots/:id/follow', auth, async (req, res) => {
  const {
    target,
    source = 'target_followers',
    limit = 10,
    delayMin = 45000,
    delayMax = 90000,
    whitelist = [],
  } = req.body;

  const db = loadBots();
  const bot = db.bots.find((b) => b.id === req.params.id);
  if (!bot) return res.status(404).json({ ok: false, error: 'Bot tidak ditemukan' });
  if (!target) return res.status(400).json({ ok: false, error: 'target wajib' });

  bot.status = 'running';
  saveBots(db);
  logs[bot.id] = [];

  (async () => {
    try {
      const ig = await createClient({
        username: bot.username,
        password: bot.password,
        cookie: bot.cookie,
      });

      const result = await autoFollow(ig, {
        target,
        source,
        limit: Number(limit),
        delayMin: Number(delayMin),
        delayMax: Number(delayMax),
        whitelist,
        onLog: (m) => logTo(bot.id, m),
      });

      bot.status = 'idle';
      bot.last_run = Date.now();
      bot.last_result = result;
      saveBots(db);
    } catch (err) {
      bot.status = 'error';
      bot.last_result = { error: err.message };
      saveBots(db);
      logTo(bot.id, `❌ Error: ${err.message}`);
    }
  })();

  res.json({ ok: true, message: 'Auto follow dijalankan di background.' });
});

/* ---------- AUTO LIKE ---------- */
app.post('/api/bots/:id/like', auth, async (req, res) => {
  const {
    target,
    limit = 10,
    delayMin = 30000,
    delayMax = 60000,
  } = req.body;

  const db = loadBots();
  const bot = db.bots.find((b) => b.id === req.params.id);
  if (!bot) return res.status(404).json({ ok: false, error: 'Bot tidak ditemukan' });
  if (!target) return res.status(400).json({ ok: false, error: 'target wajib' });

  bot.status = 'running';
  saveBots(db);
  logs[bot.id] = [];

  (async () => {
    try {
      const ig = await createClient({
        username: bot.username,
        password: bot.password,
        cookie: bot.cookie,
      });

      const result = await autoLike(ig, {
        target,
        limit: Number(limit),
        delayMin: Number(delayMin),
        delayMax: Number(delayMax),
        onLog: (m) => logTo(bot.id, m),
      });

      bot.status = 'idle';
      bot.last_run = Date.now();
      bot.last_result = result;
      saveBots(db);
    } catch (err) {
      bot.status = 'error';
      bot.last_result = { error: err.message };
      saveBots(db);
      logTo(bot.id, `❌ Error: ${err.message}`);
    }
  })();

  res.json({ ok: true, message: 'Auto like dijalankan di background.' });
});

/* ---------- LOGS ---------- */
app.get('/api/bots/:id/logs', auth, (req, res) => {
  res.json({ ok: true, logs: logs[req.params.id] || [] });
});

app.delete('/api/bots/:id/logs', auth, (req, res) => {
  logs[req.params.id] = [];
  res.json({ ok: true });
});

/* ---------- START ---------- */
app.listen(PORT, () => {
  console.log(`🚀 Server jalan di http://localhost:${PORT}`);
  console.log(`🔑 API_KEY: ${API_KEY}`);
});